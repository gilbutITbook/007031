#include <stdio.h>
#include <stdlib.h>

/* Dummy function and structure  start*/
typedef struct HT
{
    int i;
} HashTable;

void HashInit(HashTable *hs)
{
}

void HashAdd(HashTable *hs, int value)
{
}

void HashAdd2(HashTable *hs, int key, int value)
{
}

int HashFind(HashTable *hs, int value)
{
    return 1;
}

int HashGet(HashTable *hs, int value)
{
    return 1;
}

void HashRemove(HashTable *hs, int value)
{
}

typedef struct ST
{
    int i;
} Set;

void SetInit(Set *hs)
{
}

void SetAdd(Set *hs, int value)
{
}

int SetFind(Set *hs, int value)
{
    return 1;
}

void SetRemove(Set *hs, int value)
{
}

typedef struct CT
{
    int i;
} Counter;

void CounterInit(Counter *hs)
{
}

void CounterAdd(Counter *hs, int value)
{
}

int CounterFind(Counter *hs, int value)
{
    return 1;
}

int CounterGetCount(Counter *hs, int value)
{
    return 1;
}

void CounterRemove(Counter *hs, int value)
{
}

void CounterDelete(Counter *hs, int value)
{
}

/* dummy function end */

int more(int value1, int value2)
{
    return value1 > value2;
}

void Sort(int arr[], int size)
{
    int i, j, temp;
    for (i = 0; i < (size - 1); i++)
    {
        for (j = 0; j < size - i - 1; j++)
        {
            if (more(arr[j], arr[j + 1]))
            {
                /* Swapping */
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

//5-1
int linearSearchUnsorted(int data[], int size, int value)
{
    for (int i = 0; i < size; i++)
    {
        if (value == data[i])
        {
            return 1;
        }
    }
    return 0;
}

//5-2
int linearSearchSorted(int data[], int size, int value)
{
    for (int i = 0; i < size; i++)
    {
        if (value == data[i])
            return 1;
        if (value < data[i])
            return 0;
    }
    return 0;
}

//5-3
int Binarysearch(int data[], int size, int value)
{
    int low = 0;
    int high = size - 1;
    int mid;

    while (low <= high)
    {
        mid = (low + high) / 2;
        if (data[mid] == value)
        {
            return 1;
        }
        else if (data[mid] < value)
        {
            low = mid + 1;
        }
        else
        {
            high = mid - 1;
        }
    }
    return 0;
}

//5-4
int BinarySearchRecursive(int data[], int size, int low, int high, int value)
{
    if (low > high)
        return 0;

    int mid = (low + high) / 2;
    if (data[mid] == value)
        return 1;
    else if (data[mid] < value)
        return BinarySearchRecursive(data, size, mid + 1, high, value);
    else
        return BinarySearchRecursive(data, size, low, mid - 1, value);
}

//5-5
int FirstRepeated(int data[], int size)
{
    for (int i = 0; i < size; i++)
    {
        for (int j = i + 1; j < size; j++)
        {
            if (data[i] == data[j])
                return data[i];
        }
    }
    return 0;
}

//5-6
void printRepeating(int data[], int size)
{
    printf(" Repeating elements are : ");
    for (int i = 0; i < size; i++)
    {
        for (int j = i + 1; j < size; j++)
        {
            if (data[i] == data[j])
                printf(" %d ", data[i]);
        }
    }
}

//5-7
void printRepeating2(int data[], int size)
{
    Sort(data, size);
    printf(" Repeating elements are : ");

    for (int i = 1; i < size; i++)
    {
        if (data[i] == data[i - 1])
            printf(" %d ", data[i]);
    }
}

//5-8
void printRepeating3(int data[], int size)
{
    HashTable hs;
    HashInit(&hs);

    printf(" Repeating elements are : ");
    for (int i = 0; i < size; i++)
    {
        if (HashFind(&hs, data[i]))
            printf(" %d ", data[i]);
        else
            HashAdd(&hs, data[i]);
    }
}

//5-9
void printRepeating4(int data[], int size)
{
    int *count = (int *)malloc(sizeof(int) * size);
    for (int i = 0; i < size; i++)
    {
        count[i] = 0;
    }
    printf("Repeating elements are : ");
    for (int i = 0; i < size; i++)
    {
        if (count[data[i]] == 1)
            printf(" %d ", data[i]);
        else
            count[data[i]]++;
    }
}

//5-10
int removeDuplicates(int data[], int size)
{
    int j = 0;
    if (size == 0)
        return 0;

    Sort(data, size);
    for (int i = 1; i < size; i++)
    {
        if (data[i] != data[j])
        {
            j++;
            data[j] = data[i];
        }
    }
    return j + 1;
}

int main()
{
    int first[] = {1, 3, 5, 7, 9, 25, 30};
    int second[] = {2, 4, 6, 8, 10, 12, 14, 16, 21, 23, 24};

    for (int i = 1; i < 16; i++)
    {
        printf("Index %d :: Value %d \n", i, removeDuplicates(first, sizeof(first) / sizeof(int)));
    }
    return 0;
}

//5-11
int findMissingNumber(int data[], int size)
{
    int found;
    for (int i = 1; i <= size; i++)
    {
        found = 0;
        for (int j = 0; j < size; j++)
        {
            if (data[j] == i)
            {
                found = 1;
                break;
            }
        }
        if (found == 0)
        {
            return i;
        }
    }
    printf("NoNumberMissing");
}

//5-12
int findMissingNumber2(int data[], int size, int range)
{
    int xorSum = 0;
    // 1부터 범위 내의 모든 수를 XOR합니다.   
    for (int i = 1; i <= range; i++)
    {
        xorSum ^= i;
    }
    // 반복문을 돌며 배열의 모든 원소를 XOR합니다.
    for (int i = 0; i < size; i++)
    {
        xorSum ^= data[i];
    }
    return xorSum;
}

//5-13
int findMissingNumber3(int arr[], int size, int upperRange)
{
    Set st;
    SetInit(&st);
    int i = 0;
    while (i < size)
    {
        SetAdd(&st, arr[i]);
        i += 1;
    }
    i = 1;
    while (i <= upperRange)
    {
        if (SetFind(&st, i) == 0)
            return i;
        i += 1;
    }
    return -1;
}

//5-14
void MissingValues(int arr[], int size)
{
    Sort(arr, size);
    int value = arr[0];
    int i = 0;
    printf("Missing Values are :: ");
    while (i < size)
    {
        if (value == arr[i])
        {
            value += 1;
            i += 1;
        }
        else
        {
            printf(" %d ", value);
            value += 1;
        }
    }
}

//5-15
void MissingValues2(int arr[], int size)
{
    HashTable ht;
    HashInit(&ht);

    int minVal = 999999;
    int maxVal = -999999;

    for (int i = 0; i < size; i++)
    {
        HashAdd(&ht, arr[i]);
        if (minVal > arr[i])
            minVal = arr[i];
        if (maxVal < arr[i])
            maxVal = arr[i];
    }
    for (int i = minVal; i < maxVal + 1; i++)
    {
        if (HashFind(&ht, i) == 0)
            printf(" %d ", i);
    }
}

//5-16
void OddCount(int arr[], int size)
{
    Counter ctr;
    CounterInit(&ctr);
    Set st;
    SetInit(&st);
    int count;

    for (int i = 0; i < size; i++)
    {
        CounterAdd(&ctr, arr[i]);
    }
    for (int i = 0; i < size; i++)
    {
        count = CounterGetCount(&ctr, arr[i]);
        if (count > 0 && (count % 2 == 1))
        {
            printf("%d", count);
            CounterDelete(&ctr, arr[i]);
        }
    }
}

//5-17
void OddCount2(int arr[], int size)
{
    int xorSum = 0;
    int first = 0;
    int second = 0;
    int setBit;
    /*
    arr[]에 있는 모든 원소를 XOR 합니다.
    짝수 번 출현하는 원소는 서로 상쇄되어 0으로 사라집니다.
    합에는 홀수 원소의 합만 남게 됩니다.
    */
    for (int i = 0; i < size; i++)
        xorSum = xorSum ^ arr[i];
    /* 오른쪽 끝 설정 비트 설정.*/ 
    setBit = xorSum & ~(xorSum - 1);
    /*
    setBit의 bit가 1인 원소와 0인 원소의 두 그룹으로 원소를 나눕니다.
    짝수 원소들은 스스로 없어지고 찾는 숫자를 얻습니다.
    */
    for (int i = 0; i < size; i++)
    {
        if (arr[i] & setBit)
            first = first ^ arr[i];
        else
            second = second ^ arr[i];
    }
    printf(" %d & %d ", first, second);
}

//5-18
void SumDistinct(int arr[], int size)
{
    int sum = 0;
    Sort(arr, size);
    for (int i = 0; i < (size - 1); i++)
    {
        if (arr[i] != arr[i + 1])
            sum += arr[i];
    }
    sum += arr[size - 1];
    printf(" %d ", sum);
}

//5-19, 5-29
void minabsSumPair(int data[], int size)
{
    int minSum, sum, minFirst, minSecond;

    // 배열에는 적어도 2 개의 원소가 있어야 합니다.
    if (size < 2)
    {
        printf("InvalidInput");
    }
    minFirst = 0;
    minSecond = 1;
    minSum = abs(data[0] + data[1]);
    for (int l = 0; l < size - 1; l++)
    {
        for (int r = l + 1; r < size; r++)
        {
            sum = abs(data[l] + data[r]);
            if (sum < minSum)
            {
                minSum = sum;
                minFirst = l;
                minSecond = r;
            }
        }
    }
    printf(" The two elements with minimum sum are : %d, %d ", data[minFirst], data[minSecond]);
}

//5-20, 5-29
void minabsSumPair2(int data[], int size)
{
    int minSum, sum, minFirst, minSecond;
    // 배열에는 적어도 2개의 원소가 있어야 합니다.
    if (size < 2)
    {
        printf("InvalidInput");
    }
    Sort(data, size);

    // 값을 초기화합니다.
    minFirst = 0;
    minSecond = size - 1;
    minSum = abs(data[minFirst] + data[minSecond]);
    for (int l = 0, r = size - 1; l < r;)
    {
        sum = (data[l] + data[r]);
        if (abs(sum) < minSum)
        {
            minSum = abs(sum);
            minFirst = l;
            minSecond = r;
        }

        if (sum < 0)
            l++;
        else if (sum > 0)
            r--;
        else
            break;
    }
    printf(" The two elements with minimum sum are : %d , %d ", data[minFirst], data[minSecond]);
}


//5-21
int FindPair(int data[], int size, int value)
{
    for (int i = 0; i < size; i++)
    {
        for (int j = i + 1; j < size; j++)
        {
            if ((data[i] + data[j]) == value)
            {
                printf("The pair is : %d , %d ", data[i], data[j]);
                return 1;
            }
        }
    }
    return 0;
}

//5-22
int FindPair2(int data[], int size, int value)
{
    int first = 0, second = size - 1;
    int curr;
    Sort(data, size);
    while (first < second)
    {
        curr = data[first] + data[second];
        if (curr == value)
        {
            printf("The pair is %d , %d ", data[first], data[second]);
            return 1;
        }
        else if (curr < value)
            first++;
        else
            second--;
    }
    return 0;
}

//5-23
int FindPair3(int data[], int size, int value)
{
    HashTable hs;
    HashInit(&hs);

    for (int i = 0; i < size; i++)
    {
        if (HashFind(&hs, value - data[i]))
        {
            printf("The pair is : %d , %d ", data[i], (value - data[i]));
            return 1;
        }
        HashAdd(&hs, data[i]);
    }
    return 0;
}

//5-24
int FindDifference(int arr[], int size, int value)
{
    for (int i = 0; i < size; i++)
    {
        for (int j = i + 1; j < size; j++)
        {
            if (abs(arr[i] - arr[j]) == value)
                printf("The pair is:: %d & %d ", arr[i], arr[j]);
            return 1;
        }
    }
    return 0;
}

//5-25
int FindDifference2(int arr[], int size, int value)
{
    int first = 0;
    int second = 0;
    int diff;
    Sort(arr, size);
    while (first < size && second < size)
    {
        diff = abs(arr[first] - arr[second]);
        if (diff == value)
        {
            printf("The pair is:: %d & %d ", arr[first], arr[second]);
            return 1;
        }
        else if (diff > value)
            first += 1;
        else
            second += 1;
    }
    return 0;
}

//5-26
int findMinDiff(int arr[], int size)
{
    Sort(arr, size);
    int diff = 9999999;

    for (int i = 0; i < (size - 1); i++)
    {
        if ((arr[i + 1] - arr[i]) < diff)
            diff = arr[i + 1] - arr[i];
    }
    return diff;
}

//5-27
int MinDiffPair(int arr1[], int size1, int arr2[], int size2)
{
    int minDiff = 9999999;
    int first = 0;
    int second = 0;
    int out1, out2, diff;
    Sort(arr1, size1);
    Sort(arr2, size2);
    while (first < size1 && second < size2)
    {
        diff = abs(arr1[first] - arr2[second]);
        if (minDiff > diff)
        {
            minDiff = diff;
            out1 = arr1[first];
            out2 = arr2[second];
        }
        if (arr1[first] < arr2[second])
            first += 1;
        else
            second += 1;
    }
    printf("The pair is :: %d, %d \n", out1, out2);
    printf("Minimum difference is :: %d \n", minDiff);
    return minDiff;
}

//5-30
void ClosestPair(int arr[], int size, int value)
{
    int diff = 999999;
    int first = -1;
    int second = -1;
    int curr;
    for (int i = 0; i < size; i++)
    {
        for (int j = i + 1; j < size; j++)
        {
            curr = abs(value - (arr[i] + arr[j]));
            if (curr < diff)
            {
                diff = curr;
                first = arr[i];
                second = arr[j];
            }
        }
    }
    printf("closest pair is :: %d, %d ", first, second);
}

//5-31
void ClosestPair2(int arr[], int size, int value)
{
    int first = 0, second = 0;
    int start = 0;
    int stop = size - 1;
    int diff, curr;
    Sort(arr, size);
    diff = 9999999;
    {
        while (start < stop)
        {
            curr = (value - (arr[start] + arr[stop]));
            if (abs(curr) < diff)
            {
                diff = abs(curr);
                first = arr[start];
                second = arr[stop];
            }
            if (curr == 0)
            {
                break;
            }
            else if (curr > 0)
            {
                start += 1;
            }
            else
            {
                stop -= 1;
            }
        }
    }
    printf("closest pair is :: %d, %d \n", first, second);
}

//5-32
int SumPairRestArray(int arr[], int size)
{
    int total, low, high, curr, value;
    Sort(arr, size);
    total = 0;
    for (int i = 0; i < size; i++)
        total += arr[i];
    value = total / 2;
    low = 0;
    high = size - 1;
    while (low < high)
    {
        curr = arr[low] + arr[high];
        if (curr == value)
        {
            printf("Pair is :: %d, %d", arr[low], arr[high]);
            return 1;
        }
        else if (curr < value)
            low += 1;
        else
            high -= 1;
    }
    return 0;
}

//5-33
void ZeroSumTriplets(int arr[], int size)
{
    for (int i = 0; i < (size - 2); i++)
    {
        for (int j = i + 1; j < (size - 1); j++)
        {
            for (int k = j + 1; k < size; k++)
            {
                if (arr[i] + arr[j] + arr[k] == 0)
                    printf("Triplet :: %d, %d, %d \n", arr[i], arr[j], arr[k]);
            }
        }
    }
}

//5-34
void ZeroSumTriplets2(int arr[], int size)
{
    int start, stop, i;
    Sort(arr, size);
    for (i = 0; i < (size - 2); i++)
    {
        start = i + 1;
        stop = size - 1;

        while (start < stop)
        {
            if (arr[i] + arr[start] + arr[stop] == 0)
            {
                printf("Triplet :: %d %d %d", arr[i], arr[start], arr[stop]);
                start += 1;
                stop -= 1;
            }
            else if (arr[i] + arr[start] + arr[stop] > 0)
                stop -= 1;
            else
                start += 1;
        }
    }
}

//5-35
void findTriplet(int arr[], int size, int value)
{
    for (int i = 0; i < (size - 2); i++)
        for (int j = i + 1; j < (size - 1); j++)
            for (int k = j + 1; k < size; k++)
            {
                if ((arr[i] + arr[j] + arr[k]) == value)
                    printf("Triplet :: %d, %d, %d", arr[i], arr[j], arr[k]);
            }
}

//5-36
void findTriplet2(int arr[], int size, int value)
{
    int start, stop;
    Sort(arr, size);
    for (int i = 0; i < size - 2; i++)
    {
        start = i + 1;
        stop = size - 1;
        while (start < stop)
        {
            if (arr[i] + arr[start] + arr[stop] == value)
            {
                printf("Triplet ::%d, %d, %d", arr[i], arr[start], arr[stop]);
                start += 1;
                stop -= 1;
            }
            else if (arr[i] + arr[start] + arr[stop] > value)
                stop -= 1;
            else
                start += 1;
        }
    }
}

//5-37
void ABCTriplet(int arr[], int size)
{
    int start, stop;
    Sort(arr, size);
    for (int i = 0; i < (size - 2); i++)
    {
        start = i + 1;
        stop = size - 1;
        while (start < stop)
        {
            if (arr[i] == arr[start] + arr[stop])
            {
                printf("Triplet ::%d, %d, %d", arr[i], arr[start], arr[stop]);
                start += 1;
                stop -= 1;
            }
            else if (arr[i] > arr[start] + arr[stop])
                stop -= 1;
            else
                start += 1;
        }
    }
}

//5-38
void SmallerThenTripletCount(int arr[], int size, int value)
{
    int start, stop;
    int count = 0;
    Sort(arr, size);

    for (int i = 0; i < (size - 2); i++)
    {
        start = i + 1;
        stop = size - 1;
        while (start < stop)
        {
            if (arr[i] + arr[start] + arr[stop] >= value)
                stop -= 1;
            else
            {
                count += stop - start;
                start += 1;
            }
        }
    }
    printf("%d", count);
}

//5-39
void APTriplets(int arr[], int size)
{
    int i, j, k;
    for (i = 1; i < size - 1; i++)
    {
        j = i - 1;
        k = i + 1;
        while (j >= 0 && k < size)
        {
            if (arr[j] + arr[k] == 2 * arr[i])
            {
                printf("Triplet ::%d, %d, %d", arr[j], arr[i], arr[k]);
                k += 1;
                j -= 1;
            }
            else if (arr[j] + arr[k] < 2 * arr[i])
                k += 1;
            else
                j -= 1;
        }
    }
}

//5-40
void GPTriplets(int arr[], int size)
{
    int i, j, k;
    for (i = 1; i < size - 1; i++)
    {
        j = i - 1;
        k = i + 1;
        while (j >= 0 && k < size)
        {
            if (arr[j] * arr[k] == arr[i] * arr[i])
            {
                printf("Triplet is :: %d,%d,%d", arr[j], arr[i], arr[k]);
                k += 1;
                j -= 1;
            }
            else if (arr[j] + arr[k] < 2 * arr[i])
                k += 1;
            else
                j -= 1;
        }
    }
}

//5-41
int numberOfTriangles(int arr[], int size)
{
    int i, j, k, count = 0;

    for (i = 0; i < (size - 2); i++)
    {
        for (j = i + 1; j < (size - 1); j++)
        {
            for (k = j + 1; k < size; k++)
            {
                if (arr[i] + arr[j] > arr[k])
                    count += 1;
            }
        }
    }
    return count;
}

//5-42
int numberOfTriangles2(int arr[], int size)
{
    int i, j, k, count = 0;
    Sort(arr, size);

    for (i = 0; i < (size - 2); i++)
    {
        k = i + 2;
        for (j = i + 1; j < (size - 1); j++)
        {
            /*
            arr[i]와 arr[j]의 합이 arr[k]보다 크다면
            arr[i]와 arr[j + 1]의 합도 arr[k]보다 큽니다.
            O(n2)로 성능을 개선합니다.
            */
            while (k < size && arr[i] + arr[j] > arr[k])
                k += 1;

            count += k - j - 1;
        }
    }
    return count;
}

//5-43
int getMax(int data[], int size)
{
    int max = data[0], count = 1, maxCount = 1;
    for (int i = 0; i < size; i++)
    {
        count = 1;
        for (int j = i + 1; j < size; j++)
        {
            if (data[i] == data[j])
                count++;
        }
        if (count > maxCount)
        {
            max = data[i];
            maxCount = count;
        }
    }
    return max;
}

//5-44
int getMax2(int data[], int size)
{
    int max = data[0], maxCount = 1;
    int curr = data[0], currCount = 1;
    Sort(data, size);
    for (int i = 1; i < size; i++)
    {
        if (data[i] == data[i - 1])
            currCount++;
        else
        {
            currCount = 1;
            curr = data[i];
        }
        if (currCount > maxCount)
        {
            maxCount = currCount;
            max = curr;
        }
    }
    return max;
}

//5-45
int getMax3(int data[], int size, int range)
{
    int max = data[0], maxCount = 1;

    int *count = (int *)malloc(sizeof(int) * range);
    for (int i = 0; i < size; i++)
    {
        count[data[i]]++;
        if (count[data[i]] > maxCount)
        {
            maxCount = count[data[i]];
            max = data[i];
        }
    }
    return max;
}

//5-46
int getMajority(int data[], int size)
{
    int max = 0, count = 0, maxCount = 0;
    for (int i = 0; i < size; i++)
    {
        for (int j = i + 1; j < size; j++)
        {
            if (data[i] == data[j])
            {
                count++;
            }
        }
        if (count > maxCount)
        {
            max = data[i];
            maxCount = count;
        }
    }
    if (maxCount > size / 2)
        return max;
    else
    {
        printf("MajorityDoesNotExist");
        return 0;
    }
}

//5-47
int getMajority2(int data[], int size)
{
    int majIndex = size / 2, count = 1;
    int candidate;
    Sort(data, size);
    candidate = data[majIndex];
    count = 0;
    for (int i = 0; i < size; i++)
    {
        if (data[i] == candidate)
            count++;
    }

    if (count > size / 2)
        return data[majIndex];
    else
    {
        printf("MajorityDoesNotExist");
        return 0;
    }
}

//5-48
int getMajority3(int data[], int size)
{
    int majIndex = 0, count = 1;
    int candidate;

    for (int i = 1; i < size; i++)
    {
        if (data[majIndex] == data[i])
            count++;
        else
            count--;

        if (count == 0)
        {
            majIndex = i;
            count = 1;
        }
    }
    candidate = data[majIndex];
    count = 0;
    for (int i = 0; i < size; i++)
    {
        if (data[i] == candidate)
        {
            count++;
        }
    }
    if (count > size / 2)
        return data[majIndex];
    else
    {
        printf("MajorityDoesNotExist");
        return 0;
    }
}

//5-49
/* 이진 검색을 메서드를 사용합니다.*/
int FirstIndex(int arr[], int size, int low, int high, int value)
{
    int mid;
    if (high >= low)
        mid = (low + high) / 2;

    /*
    값의 첫 번째 출현을 찾습니다. 
    배열의 첫 번째 원소거나 
    중간값 직전의 값이 value보다 작거나 value과와 같은 값이어야 합니다.
    */
    if ((mid == 0 || arr[mid - 1] < value) && (arr[mid] == value))
        return mid;
    else if (arr[mid] < value)
        return FirstIndex(arr, size, mid + 1, high, value);
    else
        return FirstIndex(arr, size, low, mid - 1, value);
    return -1;
}

int isMajority(int arr[], int size)
{
    int i;
    int majority = arr[size / 2];
    i = FirstIndex(arr, size, 0, size - 1, majority);
    /*
    배열의 과반 원소를 사용하고 있기 때문에 항상 적절한 인덱스를 얻습니다. 
    */
    if (((i + size / 2) <= (size - 1)) && arr[i + size / 2] == majority)
        return 1;
    else
        return 0;
}


//5-50
int getMedian(int data[], int size)
{
    Sort(data, size);
    return data[size / 2];
}

//5-51
int SearchBotinicArrayMax(int data[], int size)
{
    int start = 0, end = size - 1;
    int mid = (start + end) / 2;
    int maximaFound = 0;
    if (size < 3)
    {
        printf("InvalidInput");
    }
    while (start <= end)
    {
        mid = (start + end) / 2;
        if (data[mid - 1] < data[mid] && data[mid + 1] < data[mid]) // 최댓값
        {
            maximaFound = 1;
            break;
        }
        else if (data[mid - 1] < data[mid] && data[mid] < data[mid + 1]) // 증가
            start = mid + 1;
        else if (data[mid - 1] > data[mid] && data[mid] > data[mid + 1]) // 감소
            end = mid - 1;
        else
            break;
    }

    if (maximaFound == 0)
    {
        printf("NoMaximaFound");
        return 0;
    }

    return data[mid];
}

int FindMaxBitonicArray(int data[], int size)
{
    int start = 0, end = size - 1, mid;
    if (size < 3)
    {
        printf("InvalidInput");
    }
    while (start <= end)
    {
        mid = (start + end) / 2;
        if (data[mid - 1] < data[mid] && data[mid + 1] < data[mid]) // 최댓값
            return mid;
        else if (data[mid - 1] < data[mid] && data[mid] < data[mid + 1]) // 증가
            start = mid + 1;
        else if (data[mid - 1] > data[mid] && data[mid] > data[mid + 1]) // 감소
            end = mid - 1;
        else
            break;
    }
    printf("Maxima not found");
    return -1;
}

int BinarySearch(int data[], int start, int end, int key, int isInc)
{
    int mid;
    if (end < start)
        return -1;

    mid = (start + end) / 2;
    if (key == data[mid])
        return mid;

    if (isInc != 0 && key < data[mid] || isInc == 0 && key > data[mid])
        return BinarySearch(data, start, mid - 1, key, isInc);
    else
        return BinarySearch(data, mid + 1, end, key, isInc);
}

//5-52
int SearchBitonicArray(int data[], int size, int key)
{
    int max = FindMaxBitonicArray(data, size);
    int k = BinarySearch(data, 0, max, key, 1);
    if (k != -1)
        return k;
    else
        return BinarySearch(data, max + 1, size - 1, key, 0);
}

//5-53
int findKeyCount(int data[], int size, int key)
{
    int count = 0;
    for (int i = 0; i < size; i++)
    {
        if (data[i] == key)
            count++;
    }
    return count;
}


int findFirstIndex(int data[], int size, int start, int end, int key)
{
    int mid;
    if (end < start)
        return -1;

    mid = (start + end) / 2;
    if (key == data[mid] && (mid == start || data[mid - 1] != key))
        return mid;

    if (key <= data[mid]) // 정렬된 배열의 숫자입니다.
        return findFirstIndex(data, size, start, mid - 1, key);
    else
        return findFirstIndex(data, size, mid + 1, end, key);
}

int findLastIndex(int data[], int size, int start, int end, int key)
{
    int mid;
    if (end < start)
        return -1;

    mid = (start + end) / 2;
    if (key == data[mid] && (mid == end || data[mid + 1] != key))
        return mid;

    if (key < data[mid])
        return findLastIndex(data, size, start, mid - 1, key);
    else
        return findLastIndex(data, size, mid + 1, end, key);
}


int findKeyCount2(int data[], int size, int key)
{
    int firstIndex, lastIndex;
    firstIndex = findFirstIndex(data, size, 0, size - 1, key);
    lastIndex = findLastIndex(data, size, 0, size - 1, key);
    return (lastIndex - firstIndex + 1);
}

void swap(int data[], int first, int second)
{
    int temp = data[first];
    data[first] = data[second];
    data[second] = temp;
}

void seperateEvenAndOdd(int data[], int size)
{
    int left = 0, right = size - 1;
    while (left < right)
    {
        if (data[left] % 2 == 0)
            left++;
        else if (data[right] % 2 == 1)
            right--;
        else
        {
            swap(data, left, right);
            left++;
            right--;
        }
    }
}

//5-55
void maxProfit(int stocks[], int size)
{
    int buy = 0, sell = 0;
    int curMin = 0;
    int currProfit = 0;
    int maxProfit = 0;

    for (int i = 0; i < size; i++)
    {
        if (stocks[i] < stocks[curMin])
            curMin = i;

        currProfit = stocks[i] - stocks[curMin];
        if (currProfit > maxProfit)
        {
            buy = curMin;
            sell = i;
            maxProfit = currProfit;
        }
    }
    printf("Purchase day is:: %d at price:: %d \n", buy, stocks[buy]);
    printf("Sell day is:: %d at price:: %d \n", sell, stocks[sell]);
}

//5-56
int findMedian(int dataFirst[], int sizeFirst, int dataSecond[], int sizeSecond)
{
    int medianIndex = ((sizeFirst + sizeSecond) + (sizeFirst + sizeSecond) % 2) / 2; // 올림 함수
    int i = 0, j = 0;
    int count = 0;
    while (count < medianIndex - 1)
    {
        if (i < sizeFirst - 1 && dataFirst[i] < dataSecond[j])
        {
            i++;
        }
        else
        {
            j++;
        }
        count++;
    }
    if (dataFirst[i] < dataSecond[j])
    {
        return dataFirst[i];
    }
    else
    {
        return dataSecond[j];
    }
}

int min(int a, int b)
{
    return a > b ? b : a;
}

int max(int a, int b)
{
    return a < b ? b : a;
}

//5-57
int BinarySearch01Util(int data[], int start, int end)
{
    int mid;
    if (end < start)
    {
        return -1;
    }
    mid = (start + end) / 2;
    if (1 == data[mid] && 0 == data[mid - 1])
    {
        return mid;
    }
    if (0 == data[mid])
    {
        return BinarySearch01Util(data, mid + 1, end);
    }
    else
    {
        return BinarySearch01Util(data, start, mid - 1);
    }
}

int BinarySearch01(int data[], int size)
{
    if (size == 1 && data[0] == 1)
    {
        return 0;
    }
    return BinarySearch01Util(data, 0, size - 1);
}

//5-58
int RotationMaxUtil(int arr[], int start, int end)
{
    int mid;
    if (end <= start)
    {
        return arr[start];
    }
    mid = (start + end) / 2;
    if (arr[mid] > arr[mid + 1])
        return arr[mid];

    if (arr[start] <= arr[mid]) /* 증가 부분.*/
        return RotationMaxUtil(arr, mid + 1, end);
    else
        return RotationMaxUtil(arr, start, mid - 1);
}

int RotationMax(int arr[], int size)
{
    return RotationMaxUtil(arr, 0, size - 1);
}

/* 테스트 코드 
first = [34, 56, 1, 1, 5, 6, 6, 6, 6, 6, 6, 7, 8, 10, 13, 20, 30 ]
second = [1, 5, 6,6,6,6,6,6,7,8,10, 13, 20, 30 ]
print(RotationMax(first))
print(RotationMax(second))
*/

//5-59
int FindRotationMaxUtil(int arr[], int start, int end)
{
    /* 1개 원소의 경우 */  
    int mid;
    if (end <= start)
        return start;

    mid = (start + end) / 2;
    if (arr[mid] > arr[mid + 1])
        return mid;

    if (arr[start] <= arr[mid]) /* 증가 부분 */
        return FindRotationMaxUtil(arr, mid + 1, end);
    else
        return FindRotationMaxUtil(arr, start, mid - 1);
}

int FindRotationMax(int arr[], int size)
{
    return FindRotationMaxUtil(arr, 0, size - 1);
}

/* 테스트 코드
first = [34, 56, 1, 1, 5, 6, 6, 6, 6, 6, 6, 7, 8, 10, 13, 20, 30 ]
second = [1, 5, 6,6,6,6,6,6,7,8,10, 13, 20, 30 ]
print(FindRotationMax(first))
print(FindRotationMax(second))
*/

//5-60
int CountRotation(int arr[], int size)
{
    int maxIndex = FindRotationMaxUtil(arr, 0, size - 1);
    return (maxIndex + 1) % size;
}
/* 테스트 코드
first = [34, 56, 1, 1, 5, 6, 6, 6, 6, 6, 6, 7, 8, 10, 13, 20, 30 ]
second = [1, 5, 6,6,6,6,6,6,7,8,10, 13, 20, 30 ]
print(CountRotation(first))
print(CountRotation(second))
*/

//5-61
int BinarySearchRotateArrayUtil(int data[], int start, int end, int key)
{
    int mid;
    if (end < start)
        return -1;

    mid = (start + end) / 2;
    if (key == data[mid])
        return mid;

    if (data[mid] > data[start])
    {
        if (data[start] <= key && key < data[mid])
        {
            return BinarySearchRotateArrayUtil(data, start, mid - 1, key);
        }
        else
        {
            return BinarySearchRotateArrayUtil(data, mid + 1, end, key);
        }
    }
    else
    {
        if (data[mid] < key && key <= data[end])
        {
            return BinarySearchRotateArrayUtil(data, mid + 1, end, key);
        }
        else
        {
            return BinarySearchRotateArrayUtil(data, start, mid - 1, key);
        }
    }
}

int BinarySearchRotateArray(int data[], int size, int key)
{
    return BinarySearchRotateArrayUtil(data, 0, size - 1, key);
}

//5-62
int minAbsDiffAdjCircular(int arr[], int size)
{
    int diff = 9999999;
    if (size < 2)
        return -1;

    for (int i = 0; i < size; i++)
        diff = min(diff, abs(arr[i] - arr[(i + 1) % size]));

    return diff;
}
/* 테스트 코드
arr = [5, 29, 18, 51, 11]
print minAbsDiffAdjCircular(arr)
*/

//5-63
void transformArrayAB1(int data[], int size)
{
    int N = size / 2;
    for (int i = 1; i < N; i++)
    {
        for (int j = 0; j < i; j++)
            swap(data, N - i + 2 * j, N - i + 2 * j + 1);
    }
}

//5-64
int checkPermutation(int data1[], int size1, int data2[], int size2)
{
    if (size1 != size2)
        return 0;

    Sort(data1, size1);
    Sort(data2, size2);

    for (int i = 0; i < size1; i++)
    {
        if (data1[i] != data2[i])
            return 0;
    }
    return 1;
}

//5-65
int checkPermutation2(int array1[], int size1, int array2[], int size2)
{
    int i;
    if (size1 != size2)
        return 0;
    HashTable hs;
    HashInit(&hs);

    for (i = 0; i < size1; i++)
        HashAdd(&hs, array1[i]);

    for (i = 0; i < size2; i++)
    {
        if (!HashFind(&hs, array2[i]))
            return 0;
    }
    return 1;
}
////////////////////

//5-66
int FindElementIn2DArray(int **arr, int r, int c, int value)
{
    int row = 0;
    int column = c - 1;
    while (row < r && column >= 0)
        if (arr[row][column] == value)
            return 1;
        else if (arr[row][column] > value)
            column -= 1;
        else
            row += 1;
    return 0;
}

//5-67
int isAP(int arr[], int size)
{
    int diff;
    if (size <= 1)
        return 1;

    Sort(arr, size);
    diff = arr[1] - arr[0];
    for (int i = 2; i < size; i++)
    {
        if (arr[i] - arr[i - 1] != diff)
            return 0;
    }
    return 1;
}

//5-68
int isAP2(int arr[], int size)
{
    int first = 9999999;
    int second = 9999999;
    int diff, value;
    HashTable hs;
    HashInit(&hs);
    for (int i = 0; i < size; i++)
    {
        if (arr[i] < first)
        {
            second = first;
            first = arr[i];
        }
        else if (arr[i] < second)
            second = arr[i];
    }
    diff = second - first;

    for (int i = 0; i < size; i++)
    {
        if (HashFind(&hs, arr[i]))
            return 0;
        HashAdd(&hs, arr[i]);
    }
    for (int i = 0; i < size; i++)
    {
        value = first + i * diff;
        if (!HashFind(&hs, value) || HashGet(&hs, value) != 1)
            return 0;
    }
    return 1;
}

//5-69
int isAP3(int arr[], int size)
{
    int first = 9999999;
    int second = 9999999;
    int *count = (int *)calloc(0, size);
    int diff, index;
    for (int i = 0; i < size; i++)
    {
        if (arr[i] < first)
        {
            second = first;
            first = arr[i];
        }
        else if (arr[i] < second)
            second = arr[i];
    }
    diff = second - first;

    for (int i = 0; i < size; i++)
        index = (arr[i] - first) / diff;
    if (index > size - 1 || count[index] != 0)
        return 0;
    count[index] = 1;

    for (int i = 0; i < size; i++)
        if (count[i] != 1)
            return 0;
    return 1;
}

//5-70
int findBalancedPoint(int arr[], int size)
{
    int first = 0;
    int second = 0;
    for (int i = 1; i < size; i++)
        second += arr[i];

    for (int i = 0; i < size; i++)
    {
        if (first == second)
            printf("%d", i);
        if (i < size - 1)
            first += arr[i];
        second -= arr[i + 1];
    }
}

/* 테스트 코드
arr = [-7, 1, 5, 2, -4, 3, 0]
findBalancedPoint(arr)
*/

//5-71
int findFloor(int arr[], int size, int value)
{
    int start = 0;
    int stop = size - 1;
    int mid;
    while (start <= stop)
    {
        mid = (start + stop) / 2;
        /* 검색 값은 arr[mid] 값과 같습니다.
        검색 값은 중간 인덱스(mid) 값보다 크고 중간 인덱스+1 값보다 작습니다.
        값이 arr[size-1]보다 크면 바닥은 arr[size-1]입니다.
		*/
        if (arr[mid] == value || (arr[mid] < value && (mid == size - 1 || arr[mid + 1] > value)))
            return mid;
        else if (arr[mid] < value)
            start = mid + 1;
        else
            stop = mid - 1;
    }
    return -1;
}

//5-72
int findCeil(int arr[], int size, int value)
{
    int start = 0;
    int stop = size - 1;
    int mid;

    while (start <= stop)
    {
        mid = (start + stop) / 2;
        /* 검색 값은 arr[mid] 값과 같습니다.
        검색 값은 중간 인덱스 값보다 작고 중간 인덱스-1 값보다 큽니다.
        값이 arr[size-1]보다 작으면 천장은 arr[0]입니다.
		*/
        if (arr[mid] == value || (arr[mid] > value && (mid == 0 || arr[mid - 1] < value)))
            return mid;
        else if (arr[mid] < value)
            start = mid + 1;
        else
            stop = mid - 1;
    }
    return -1;
}

//5-73
int ClosestNumber(int arr[], int size, int num)
{
    int start = 0;
    int stop = size - 1;
    int output = -1;
    int minDist = 9999;
    int mid;

    while (start <= stop)
    {
        mid = (start + stop) / 2;
        if (minDist > abs(arr[mid] - num))
        {
            minDist = abs(arr[mid] - num);
            output = arr[mid];
        }
        if (arr[mid] == num)
            break;
        else if (arr[mid] > num)
            stop = mid - 1;
        else
            start = mid + 1;
    }
    return output;
}

//5-74
int DuplicateKDistance(int arr[], int size, int k)
{
    HashTable hs;
    for (int i = 0; i < size; i++)
    {
        if (HashFind(&hs, arr[i]) && i - HashGet(&hs, arr[i]) <= k)
        {
            printf("%d, %d, %d", arr[i], HashGet(&hs, arr[i]), i);
            return 1;
        }
        else
            HashAdd2(&hs, arr[i], i);
    }
    return 0;
}
/* 테스트 코드
arr = [1, 2, 3, 1, 4, 5]
DuplicateKDistance(arr, 3)
*/

//5-75
int frequencyCounts(int arr[], int size)
{
    int index;
    for (int i = 0; i < size; i++)
    {
        while (arr[i] > 0)
        {
            index = arr[i] - 1;
            if (arr[index] > 0)
            {
                arr[i] = arr[index];
                arr[index] = -1;
            }
            else
            {
                arr[index] -= 1;
                arr[i] = 0;
            }
        }
    }
    for (int i = 0; i < size; i++)
        printf("%d : %d \n", i + 1, abs(arr[i]));
}

//5-76
int KLargestElements(int arrIn[], int size, int k)
{
    int *arr = (int *)malloc(size * sizeof(int));
    for (int i = 0; i < size; i++)
        arr[i] = arrIn[i];

    Sort(arr, size);
    for (int i = 0; i < size; i++)
    {
        if (arrIn[i] >= arr[size - k])
            printf(" %d ", arrIn[i]);
    }
}
void QuickSelectUtil(int arr[], int lower, int upper, int k)
{
    if (upper <= lower)
        return;

    int pivot = arr[lower];

    int start = lower;
    int stop = upper;

    while (lower < upper)
    {
        while (arr[lower] <= pivot)
        {
            lower++;
        }
        while (arr[upper] > pivot)
        {
            upper--;
        }
        if (lower < upper)
        {
            swap(arr, upper, lower);
        }
    }

    swap(arr, upper, start); // upper는 피벗의 위치입니다.
    if (k < upper) 
        QuickSelectUtil(arr, start, upper - 1, k); // pivot - 1은 왼쪽 부분 배열의 상위 인덱스입니다.
    if (k > upper)
        QuickSelectUtil(arr, upper + 1, stop, k); // pivot + 1은 오른쪽 부분 배열의 하위 인덱스입니다.
}

//5-77
int KLargestElements2(int arrIn[], int size, int k)
{
    int *arr = (int *)malloc(size * sizeof(int));
    for (int i = 0; i < size; i++)
        arr[i] = arrIn[i];

    QuickSelectUtil(arr, 0, size - 1, size - k);
    for (int i = 0; i < size; i++)
    {
        if (arrIn[i] >= arr[size - k])
            printf("%d", arrIn[i]);
    }
}

//5-78
/* 선형 검색 메서드 */
int FixPoint(int arr[], int size)
{
    for (int i = 0; i < size; i++)
    {
        if (arr[i] == i)
            return i;
    } /* 고정 점을 찾지 못하면 유효하지 않은 인덱스를 반환합니다. */
    return -1;
}

//5-79
/* 이진 검색 메서드 */
int FixPoint2(int arr[], int size)
{
    int low = 0;
    int high = size - 1;
    int mid;
    while (low <= high)
    {
        mid = (low + high) / 2;
        if (arr[mid] == mid)
            return mid;
        else if (arr[mid] < mid)
            low = mid + 1;
        else
            high = mid - 1;
    }
    /* 고정 점을 찾지 못하면 유효하지 않은 인덱스를 반환합니다. */
    return -1;
}

//5-80
int subArraySums(int arr[], int size, int value)
{
    int first = 0;
    int second = 0;
    int sum = arr[first];
    while (second < size && first < size)
    {
        if (sum == value)
            printf("%d , %d ", first, second);

        if (sum < value)
        {
            second += 1;
            if (second < size)
                sum += arr[second];
        }
        else
        {
            sum -= arr[first];
            first += 1;
        }
    }
}

//5-81
int MaxConSub(int arr[], int size)
{
    int currMax = 0;
    int maximum = 0;
    for (int i = 0; i < size; i++)
    {
        currMax = max(arr[i], currMax + arr[i]);
        if (currMax < 0)
            currMax = 0;
        if (maximum < currMax)
            maximum = currMax;
    }
    printf(" %d ", maximum);
}

//5-82
int MaxConSubArr(int A[], int sizeA, int B[], int sizeB)
{
    int currMax = 0;
    int maximum = 0;
    HashTable hs;
    HashInit(&hs);

    for (int i = 0; i < sizeB; i++)
        HashAdd(&hs, B[i]);

    for (int i = 0; i < sizeA; i++)
        if (HashFind(&hs, A[i]))
            currMax = 0;
        else
            currMax = max(A[i], currMax + A[i]);
    if (currMax < 0)
        currMax = 0;
    if (maximum < currMax)
        maximum = currMax;
    printf(" %d ", maximum);
}

//5-83
int MaxConSubArr2(int A[], int sizeA, int B[], int sizeB)
{
    Sort(B, sizeB);
    int currMax = 0;
    int maximum = 0;

    for (int i = 0; i < sizeA; i++)
    {
        if (Binarysearch(B, sizeB, A[i]))
            currMax = 0;
        else
        {
            currMax = max(A[i], currMax + A[i]);
            if (currMax < 0)
                currMax = 0;
            if (maximum < currMax)
                maximum = currMax;
        }
    }
    printf(" %d ", maximum);
}

//5-84
int RainWater(int arr[], int size)
{
    int water = 0;
    int *leftHigh = (int *)calloc(size, sizeof(int));
    int *rightHigh = (int *)calloc(size, sizeof(int));
    int max = arr[0];
    leftHigh[0] = arr[0];
    for (int i = 1; i < size; i++)
    {
        if (max < arr[i])
            max = arr[i];
        leftHigh[i] = max;
    }
    max = arr[size - 1];
    rightHigh[size - 1] = arr[size - 1];
    for (int i = (size - 2); i >= 0; i--)
    {
        if (max < arr[i])
            max = arr[i];
        rightHigh[i] = max;
    }

    for (int i = 0; i < size; i++)
        water += min(leftHigh[i], rightHigh[i]) - arr[i];
    printf("Water : %d ", water);
}

//5-85
int RainWater2(int arr[], int size)
{
    int water = 0;
    int leftMax = 0, rightMax = 0;
    int left = 0;
    int right = size - 1;

    while (left <= right)
    {
        if (arr[left] < arr[right])
        {
            if (arr[left] > leftMax)
                leftMax = arr[left];
            else
                water += leftMax - arr[left];
            left += 1;
        }
        else
        {
            if (arr[right] > rightMax)
                rightMax = arr[right];
            else
                water += rightMax - arr[right];
            right -= 1;
        }
    }
    printf("Water : %d ", water);
}
/*
int SubArrayZeroOneEqual(int arr[], int size)
{
    int maxLength = -1;
    int start = -1, stop = -1;
    int sum = 0;
    int currLength;
    HashTable hs;
    HashInit(&hs);

    HashAdd(&hs, 0, -1);
    for (int i = 0; i < size; i++)
    {
        if (arr[i] == 1)
            sum += 1;
        else
            sum -= 1;

        if (HashFind(&hs, sum))
        {
            currLength = i - HashGet(&hs, sum);
            if (currLength > maxLength)
                maxLength = currLength;
            start = HashGet(&hs, sum);
            stop = i;
        }
        else
            HashAdd(&hs, sum, i);
    }
    printf("%d %d %d", start + 1, stop, maxLength);
}

테스트 코드
arr = [0, 0, 0, 1, 0, 1, 0]
SubArrayZeroOneEqual(arr)
*/